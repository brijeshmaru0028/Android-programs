package com.example.sqlitedemo_android;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText eid, enm, eage;
    Button add, upd, del;
    TableLayout tbl;
    sqlite sql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        eid = findViewById(R.id.id);
        enm = findViewById(R.id.nm);
        eage = findViewById(R.id.age);
        add = findViewById(R.id.add);
        upd = findViewById(R.id.up);
        del = findViewById(R.id.del);
        tbl = findViewById(R.id.tbl);
        sql = new sqlite(getApplicationContext());
        show();
        enm.requestFocus();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sql.ins(enm.getText().toString(), eage.getText().toString());
                show();
                clear();
            }
        });
        upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sql.upd(eid.getText().toString(), enm.getText().toString(), eage.getText().toString());
                show();
                clear();
            }
        });
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sql.del(eid.getText().toString());
                show();
                clear();
            }
        });
    }
    public void show() {
        Cursor c = sql.show();
        tbl.removeAllViews();
        TableRow thr = new TableRow(getApplicationContext());
        TextView th1 = new TextView(getApplicationContext());
        TextView th2 = new TextView(getApplicationContext());
        TextView th3 = new TextView(getApplicationContext());
        th1.setText("Id");
        th2.setText("Name");
        th3.setText("Age");
        th1.setPadding(50, 50, 50, 50);
        th2.setPadding(50, 50, 50, 50);
        th3.setPadding(50, 50, 50, 50);
        thr.addView(th1);
        thr.addView(th2);
        thr.addView(th3);
        thr.setBackgroundColor(Color.BLACK);
        tbl.addView(thr);
        while (c.moveToNext()) {
            TableRow tr = new TableRow(getApplicationContext());
            TextView t1 = new TextView(getApplicationContext());
            TextView t2 = new TextView(getApplicationContext());
            TextView t3 = new TextView(getApplicationContext());
            t1.setText(c.getString(0));
            t2.setText(c.getString(1));
            t3.setText(c.getString(2));
            t1.setPadding(50, 50, 50, 50);
            t2.setPadding(50, 50, 50, 50);
            t3.setPadding(50, 50, 50, 50);
            tr.addView(t1);
            tr.addView(t2);
            tr.addView(t3);
            tr.setBackgroundColor(Color.BLUE);
            tbl.addView(tr);
            tr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    eid.setText(t1.getText());
                    enm.setText(t2.getText());
                    eage.setText(t3.getText());
                }
            });
        }
    }

    public void clear(){
        eid.setText("");
        enm.setText("");
        eage.setText("");
        enm.requestFocus();
    }
}