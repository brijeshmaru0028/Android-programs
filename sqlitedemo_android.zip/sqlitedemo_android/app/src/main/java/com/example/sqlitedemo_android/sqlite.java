package com.example.sqlitedemo_android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class sqlite extends SQLiteOpenHelper {

    public sqlite(Context context)
    {
        super(context,"bm",null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table bhm(id integer primary key autoincrement,nm text,age text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists bhm");
    }

    public void ins(String nm,String age)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nm",nm);
        cv.put("age",age);
        db.insert("bhm",null,cv);
    }

    public void upd(String id,String nm,String age)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nm",nm);
        cv.put("age",age);
        db.update("bhm",cv,"id=?",new String[]{id});
    }
    public void del(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("bhm","id=?",new String[]{id});
    }

    public Cursor show()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("select * from bhm",null);
    }
}

